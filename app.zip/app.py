import os

from dotenv import load_dotenv
from flask import Flask
from flask_cors import CORS
from flask_smorest import Api

from database import db
from routers import note_blp, user_blp

# === App Setup ===
app = Flask(__name__)
CORS(app)  # السماح بالوصول من أي مصدر (Cross-Origin Resource Sharing
URL_PREFIX = "/api/v1"
load_dotenv()
# =========================
# == App Configuration ==
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_SQLITE")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
# === Flask-Smorest Configuration
app.config["API_TITLE"] = "Notes and TaskManagers API"
app.config["API_VERSION"] = "v1"
app.config["OPENAPI_VERSION"] = "3.0.3"
# =========================
# === Initialize Database and API ===
db.init_app(app)
api = Api(app)
# ==========================
# == Create Database Tables ==
with app.app_context():
    db.create_all()
# =========================
# == Register Blueprints ==
api.register_blueprint(note_blp)
api.register_blueprint(user_blp)


# == Helper Functions ==
def url_prefix(endpoint: str = "") -> str:
    return f"{URL_PREFIX}{endpoint}"


# ========================
# === EndPoints ===
@app.get(url_prefix("/"))
def index():
    return {"message": "Welcome to the API!"}, 200


@app.get(url_prefix("/health"))
def health():
    return {"status": "ok"}, 200
